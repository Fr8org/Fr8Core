﻿namespace $safeprojectname$
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        
    }
}
